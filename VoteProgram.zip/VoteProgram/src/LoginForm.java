import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import com.sun.tools.javac.Main;

public class LoginForm {
	JFrame frame = new JFrame();
	User u = new User();
	private JTextField id_textField;
	private JTextField pw_textField;
	ResultSet rs = null;
	Statement stmt = null;
	String sql = null;
	
	public LoginForm() {
		frame.setResizable(false);
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame.setBounds(100, 100, 258, 203);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("\uC544\uC774\uB514");
		lblNewLabel.setBounds(29, 68, 57, 15);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("\uBE44\uBC00\uBC88\uD638");
		lblNewLabel_1.setBounds(29, 93, 57, 15);
		frame.getContentPane().add(lblNewLabel_1);
		
		id_textField = new JTextField();
		id_textField.setBounds(98, 65, 116, 21);
		frame.getContentPane().add(id_textField);
		id_textField.setColumns(10);
		
		pw_textField = new JTextField();
		pw_textField.setColumns(10);
		pw_textField.setBounds(98, 90, 116, 21);
		frame.getContentPane().add(pw_textField);
		
		JLabel lblNewLabel_2 = new JLabel("\uB85C\uADF8\uC778");
		lblNewLabel_2.setFont(new Font("����", Font.BOLD, 30));
		lblNewLabel_2.setBounds(12, 0, 93, 67);
		frame.getContentPane().add(lblNewLabel_2);
		
		JButton loginBtn = new JButton("\uB85C\uADF8\uC778");
		loginBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					ConnectionDispenser cd = new ConnectionDispenser();
					Connection con = cd.getConnection();
					stmt = con.createStatement();
					sql = "select * from member where id='" + id_textField.getText() + "';";
					rs = stmt.executeQuery(sql);
					// member���̺��� id�� ���� ���
					if(rs.next() == false || (id_textField.getText() == "")) {
						JOptionPane.showMessageDialog(null, "�������� �ʴ� id�Դϴ�.");
					}
					// member���̺��� id�� �ִ� ���
					else {
						sql = "select * from (select * from member where id='" + id_textField.getText() + "')m";
						rs = stmt.executeQuery(sql);
						while(rs.next()==true) {
							if(rs.getString(2).equals(pw_textField.getText())) {
								System.out.println("�α��� ����");
								u.set_id(rs.getString(1));
								u.set_pw(rs.getString(2));
								u.set_name(rs.getString(3));
								u.set_state(Integer.parseInt(rs.getString(4)));
								u.set_ls(true);
								new MainForm();
								frame.dispose();
							}
							else {
								System.out.println("Ʋ�� ��й�ȣ�Դϴ�.");
							}
						}
					}
				} catch (SQLException er) {
					JOptionPane.showMessageDialog(null, er);
				}
			}
		});
		loginBtn.setBounds(131, 121, 83, 23);
		frame.getContentPane().add(loginBtn);
		frame.setDefaultCloseOperation(frame.EXIT_ON_CLOSE);
		
		frame.setVisible(true);
	}
}
