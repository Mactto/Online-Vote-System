import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.Icon;

public class MainForm {
	private ButtonGroup group;	
	private static int[] value;
	private static boolean check;
	private static boolean login_state = false;
	ImageIcon ic;
	Image k_image;
	Image new_image;
	ImageIcon image;
	JFrame frame;
	User u;
	Statement stmt;
	int rs;
	String sql;
	
	public static void main(String[] args) {
		value = new int[8];
		for(int i=0; i<value.length; i++) value[i] = 0;
		new MainForm();
	}
	public MainForm() {
		frame = new JFrame();
		u = new User();
		initialize();
	}

	private void initialize() {
		frame.getContentPane().setBackground(Color.WHITE);
		frame.setResizable(false);
		frame.setTitle("20184067 \uCD5C\uC138\uD658");
		frame.setBounds(100, 100, 700, 476);
		frame.setDefaultCloseOperation(frame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		// ============================ ��� =========================================
		// �г�
		JPanel panel1 = new JPanel();
		panel1.setBackground(Color.WHITE);
		panel1.setBounds(0, 0, 694, 60);
		panel1.setLayout(null);
		frame.getContentPane().add(panel1);

		// �α׾ƿ� ��ư
		JButton logoutBtn = new JButton("\uB85C\uADF8\uC544\uC6C3");
		logoutBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				u.set_ls(false);
				new MainForm();
				frame.dispose();
			}
		});
		logoutBtn.setBackground(Color.WHITE);
		logoutBtn.setBounds(584, 10, 92, 23);
		panel1.add(logoutBtn);
		
		// ȸ������ ��ư
		JButton registerBtn = new JButton("\uD68C\uC6D0\uAC00\uC785");
		registerBtn.setBounds(584, 10, 92, 23);
		panel1.add(registerBtn);
		registerBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new RegisterForm();
			}
		});
		registerBtn.setBackground(Color.WHITE);
				
		// �α��� ��ư
		JButton loginBtn = new JButton("\uB85C\uADF8\uC778");
		loginBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new LoginForm();
				frame.dispose();
			}
		});
		loginBtn.setBackground(Color.WHITE);
		loginBtn.setBounds(503, 10, 78, 23);
		panel1.add(loginBtn);
		
		// Ÿ��Ʋ ��
		JLabel lblNewLabel = new JLabel("\uD504\uB85C\uADF8\uB798\uBC0D \uC5B8\uC5B4 \uD22C\uD45C");
		lblNewLabel.setFont(new Font("����", Font.BOLD, 30));
		lblNewLabel.setBounds(12, 10, 323, 46);
		panel1.add(lblNewLabel);
		
		if(u.get_ls() == true) {
			loginBtn.setVisible(false);
			loginBtn.setEnabled(false);
			registerBtn.setVisible(false);
			registerBtn.setEnabled(false);
			logoutBtn.setVisible(true);
			logoutBtn.setEnabled(true);
		}
		else {
			loginBtn.setVisible(true);
			loginBtn.setEnabled(true);
			registerBtn.setVisible(true);
			registerBtn.setEnabled(true);
			logoutBtn.setVisible(false);
			logoutBtn.setEnabled(false);
		}
		// ============================ �ߴ� =========================================
		// ���� ��ư
		JRadioButton radio1 = new JRadioButton("Python");
		radio1.setBackground(Color.WHITE);
		radio1.setActionCommand("python");
		radio1.setBounds(40, 179, 72, 23);
		frame.getContentPane().add(radio1);
		JRadioButton radio2 = new JRadioButton("Java");
		radio2.setBackground(Color.WHITE);
		radio2.setBounds(216, 179, 72, 23);
		radio2.setActionCommand("java");
		frame.getContentPane().add(radio2);
		JRadioButton radio3 = new JRadioButton("C");
		radio3.setBackground(Color.WHITE);
		radio3.setBounds(384, 179, 72, 23);
		radio3.setActionCommand("c");
		frame.getContentPane().add(radio3);
		JRadioButton radio4 = new JRadioButton("C++");
		radio4.setBackground(Color.WHITE);
		radio4.setActionCommand("cpp");
		radio4.setBounds(549, 179, 72, 23);
		frame.getContentPane().add(radio4);
		JRadioButton radio7 = new JRadioButton("C#");
		radio7.setBackground(Color.WHITE);
		radio7.setActionCommand("cs");
		radio7.setBounds(384, 340, 72, 23);
		frame.getContentPane().add(radio7);
		JRadioButton radio5 = new JRadioButton("Kotlin");
		radio5.setBackground(Color.WHITE);
		radio5.setActionCommand("kotlin");
		radio5.setBounds(40, 340, 72, 23);
		frame.getContentPane().add(radio5);
		JRadioButton radio6 = new JRadioButton("R");
		radio6.setBackground(Color.WHITE);
		radio6.setActionCommand("r");
		radio6.setBounds(216, 340, 72, 23);
		frame.getContentPane().add(radio6);
		JRadioButton radio8 = new JRadioButton("Ruby");
		radio8.setBackground(Color.WHITE);
		radio8.setActionCommand("ruby");
		radio8.setBounds(549, 340, 72, 23);
		frame.getContentPane().add(radio8);
		group = new ButtonGroup();
		group.add(radio1);
		group.add(radio2);
		group.add(radio3);
		group.add(radio4);
		group.add(radio5);
		group.add(radio6);
		group.add(radio7);
		group.add(radio8);
		
		// ��ǥ�ϱ� ��ư
		JButton btnNewButton_2 = new JButton("\uD22C\uD45C\uD558\uAE30");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(u.get_ls() == false) {
					JOptionPane.showMessageDialog(null, "�α����� �ʿ��� �����Դϴ�.");
				}
				else if(u.get_state() == 1) {
					JOptionPane.showMessageDialog(null,  "�̹� ��ǥ�� ���̵��Դϴ�.");
				}
				else {
					String selection = group.getSelection().getActionCommand();
					if (selection != "") {
						// �� ��ǥ �� db�� ����
						try {
							ConnectionDispenser cd = new ConnectionDispenser();
							Connection con = cd.getConnection();
							stmt = con.createStatement();
							sql = "update member set state=1 where id='" + u.get_id() + "';";
							rs = stmt.executeUpdate(sql);
							sql = "insert into vote values('" + u.get_name() + "', '" + selection + "');";
							rs = stmt.executeUpdate(sql);
							JOptionPane.showMessageDialog(null, selection+"�� ��ǥ�Ǿ����ϴ�.");
							u.set_state(1);
						} catch (SQLException er) {
							JOptionPane.showMessageDialog(null, er);
						}	
					}
					else {
						JOptionPane.showMessageDialog(null, "�� ���õ��� �ʾҽ��ϴ�.");
					}
				}
			}
		});
		btnNewButton_2.setBounds(292, 391, 97, 23);
		frame.getContentPane().add(btnNewButton_2);
		
		
		// ========================== �̹��� �� ==========================================
		ic = new ImageIcon("src/image/python.png");
		k_image = ic.getImage();
		new_image = k_image.getScaledInstance(150, 100, Image.SCALE_SMOOTH);
		image = new ImageIcon(new_image);
		JLabel python_image = new JLabel(image);
		python_image.setBounds(10, 70, 118, 103);
		frame.getContentPane().add(python_image);
		
		
		ic = new ImageIcon("src/image/java.png");
		k_image = ic.getImage();
		new_image = k_image.getScaledInstance(150, 100, Image.SCALE_SMOOTH);
		image = new ImageIcon(new_image);
		JLabel java_image = new JLabel(image);
		java_image.setBounds(187, 70, 118, 103);
		frame.getContentPane().add(java_image);

		ic = new ImageIcon("src/image/c.png");
		k_image = ic.getImage();
		new_image = k_image.getScaledInstance(150, 100, Image.SCALE_SMOOTH);
		image = new ImageIcon(new_image);
		JLabel c_image = new JLabel(image);
		c_image.setBounds(354, 70, 118, 103);
		frame.getContentPane().add(c_image);

		ic = new ImageIcon("src/image/cpp.png");
		k_image = ic.getImage();
		new_image = k_image.getScaledInstance(150, 100, Image.SCALE_SMOOTH);
		image = new ImageIcon(new_image);
		JLabel cpp_image = new JLabel(image);
		cpp_image.setBounds(522, 70, 118, 103);
		frame.getContentPane().add(cpp_image);

		ic = new ImageIcon("src/image/kotlin.png");
		k_image = ic.getImage();
		new_image = k_image.getScaledInstance(150, 100, Image.SCALE_SMOOTH);
		image = new ImageIcon(new_image);
		JLabel kotlin_image = new JLabel(image);
		kotlin_image.setBounds(10, 227, 118, 103);
		frame.getContentPane().add(kotlin_image);

		ic = new ImageIcon("src/image/r.png");
		k_image = ic.getImage();
		new_image = k_image.getScaledInstance(150, 100, Image.SCALE_SMOOTH);
		image = new ImageIcon(new_image);
		JLabel r_image = new JLabel(image);
		r_image.setBounds(187, 227, 118, 103);
		frame.getContentPane().add(r_image);

		ic = new ImageIcon("src/image/cs.jpg");
		k_image = ic.getImage();
		new_image = k_image.getScaledInstance(150, 100, Image.SCALE_SMOOTH);
		image = new ImageIcon(new_image);
		JLabel cs_image = new JLabel(image);
		cs_image.setBounds(354, 227, 118, 103);
		frame.getContentPane().add(cs_image);

		ic = new ImageIcon("src/image/ruby.png");
		k_image = ic.getImage();
		new_image = k_image.getScaledInstance(150, 100, Image.SCALE_SMOOTH);
		image = new ImageIcon(new_image);
		JLabel ruby_image = new JLabel(image);
		ruby_image.setBounds(522, 227, 118, 103);
		frame.getContentPane().add(ruby_image);
	
		frame.setVisible(true);
	}
}