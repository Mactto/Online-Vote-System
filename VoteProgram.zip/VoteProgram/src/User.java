
public class User {
	private static String id;
	private static String pw;
	private static String name;
	private static int state;
	private static boolean login_state=false;

	
	public String get_id() {
		return id;
	}
	public void set_id(String id) {
		this.id = id;
	}
	public String get_pw() {
		return pw;
	}
	public void set_pw(String pw) {
		this.pw = pw;
	}
	public String get_name() {
		return name;
	}
	public void set_name(String name) {
		this.name = name;
	}
	public int get_state() {
		return state;
	}
	public void set_state(int state) {
		this.state = state;
	}
	public boolean get_ls() {
		return this.login_state;
	}
	public void set_ls(boolean s) {
		this.login_state = s;
	}
}
