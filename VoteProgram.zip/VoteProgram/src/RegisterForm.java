import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

public class RegisterForm {
	JFrame frame = new JFrame();
	private JTextField id_textField;
	private JTextField pw_textField;
	private JTextField pw_textField2;
	private JTextField name_textField;
	private ButtonGroup g;

	public RegisterForm() {
		frame.setResizable(false);
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame.setBounds(100, 100, 238, 261);
		frame.getContentPane().setLayout(null);
		
		// Ÿ��Ʋ ��
		JLabel lblNewLabel = new JLabel("\uD68C\uC6D0\uAC00\uC785");
		lblNewLabel.setFont(new Font("����", Font.BOLD, 30));
		lblNewLabel.setBounds(26, 10, 143, 44);
		frame.getContentPane().add(lblNewLabel);
		
		// ���̵�
		JLabel lblNewLabel_1 = new JLabel("\uD68C\uC6D0 ID");
		lblNewLabel_1.setBounds(12, 64, 57, 15);
		frame.getContentPane().add(lblNewLabel_1);
		
		// ��й�ȣ
		JLabel lblNewLabel_1_1 = new JLabel("\uBE44\uBC00\uBC88\uD638");
		lblNewLabel_1_1.setBounds(12, 88, 57, 15);
		frame.getContentPane().add(lblNewLabel_1_1);
		
		// ��й�ȣ Ȯ��
		JLabel lblNewLabel_1_2 = new JLabel("\uBE44\uBC00\uBC88\uD638 \uD655\uC778");
		lblNewLabel_1_2.setBounds(12, 113, 82, 15);
		frame.getContentPane().add(lblNewLabel_1_2);
		
		// �̸�
		JLabel lblNewLabel_1_3 = new JLabel("\uC774\uB984");
		lblNewLabel_1_3.setBounds(12, 138, 57, 15);
		frame.getContentPane().add(lblNewLabel_1_3);
		
		// ����
		JLabel lblNewLabel_1_4 = new JLabel("\uC131\uBCC4");
		lblNewLabel_1_4.setBounds(12, 163, 57, 15);
		frame.getContentPane().add(lblNewLabel_1_4);
		
		// ���� ���� ��ư
		JRadioButton man_radio = new JRadioButton("\uB0A8");
		man_radio.setBounds(98, 159, 42, 23);
		frame.getContentPane().add(man_radio);
		JRadioButton femail_radio = new JRadioButton("\uC5EC");
		femail_radio.setBounds(144, 159, 42, 23);
		frame.getContentPane().add(femail_radio);
		g = new ButtonGroup();
		g.add(man_radio);
		g.add(femail_radio);
		
		// ���̵� �ؽ�Ʈ �ʵ�
		id_textField = new JTextField();
		id_textField.setBounds(98, 61, 116, 21);
		frame.getContentPane().add(id_textField);
		id_textField.setColumns(10);
		
		// ��й�ȣ �ؽ�Ʈ �ʵ�
		pw_textField = new JTextField();
		pw_textField.setColumns(10);
		pw_textField.setBounds(98, 85, 116, 21);
		frame.getContentPane().add(pw_textField);
		
		// ��й�ȣ Ȯ�� �ؽ�Ʈ �ʵ�
		pw_textField2 = new JTextField();
		pw_textField2.setColumns(10);
		pw_textField2.setBounds(98, 110, 116, 21);
		frame.getContentPane().add(pw_textField2);
		
		// �̸� �ؽ�Ʈ �ʵ�
		name_textField = new JTextField();
		name_textField.setColumns(10);
		name_textField.setBounds(98, 135, 116, 21);
		frame.getContentPane().add(name_textField);
		
		// �����ϱ� ��ư
		JButton registerBtn = new JButton("\uAC00\uC785\uD558\uAE30");
		registerBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (pw_textField.getText().equals(pw_textField2.getText())) {
					try {
						ConnectionDispenser cd = new ConnectionDispenser();
						Connection con = cd.getConnection();
						Statement statement = con.createStatement();
						statement.executeUpdate(
								"INSERT INTO member VALUES('" 
						+ id_textField.getText() + "', '"
						+ pw_textField.getText() + "', '"
						+ name_textField.getText() + "', 0);");
						JOptionPane.showMessageDialog(null, "ȸ������ ����");
						frame.dispose();
					} catch (SQLException er) {
						JOptionPane.showMessageDialog(null, er);
					}
				}
				else {
					JOptionPane.showMessageDialog(null, "��й�ȣ�� ��ġ���� �ʽ��ϴ�.");
				}
			}
		});
		registerBtn.setBounds(117, 188, 97, 23);
		frame.getContentPane().add(registerBtn);
		frame.setDefaultCloseOperation(frame.EXIT_ON_CLOSE);
		
		frame.setVisible(true);
	}
}
